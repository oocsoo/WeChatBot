#-*-coding:utf-8 -*-
#Provide interface files for client encryption functionality

from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64
import os
import sys
import urllib
from boto3.s3.transfer import TransferConfig
from s3transfer.utils import ReadFileChunk


default_alg = "AES/GCM/NoPadding"
default_wrap_alg = "AES/GCM"
default_key_len = 32
default_iv_len = 12
default_chunk_size = 8192
default_tag_ken = 16

GB = 1024 ** 3
MB = 1024 ** 2
KB = 1024

class CipherLight(object):
    """ a cipher used to encrypted data or decrypted data
    """
    def __init__(self, key, iv):
        """
        :param key: Encryption and decryption credentials
        :param iv: Initialization vector
        """
        self.iv = iv
        self.key = key
        self.cipher = AES.new(key, AES.MODE_GCM, iv)

    def reinit_cipher(self):
        """
        reinitialize cipher
        """
        self.cipher = AES.new(self.key, AES.MODE_GCM, self.iv)

    def encrypte(self, data):
        """
        encrypted data
        """
        if (self.cipher == None):
            raise ValueError("init cipher before encrypte data")

        if (data == None):
            return None

        return self.cipher.encrypt(data)

    def encrypte_and_verify(self, data):
        """
        encrypted data and return crypted data and verify tag
        """
        if (self.cipher == None):
            raise ValueError("init cipher before encrypte data")

        return self.cipher.encrypt_and_digest(data)

    def decrypte(self, data):
        """
        decrypted data
        """
        if (self.cipher == None):
            raise ValueError("init cipher before decrypte data")

        return self.cipher.decrypt(data)

    def decrypte_and_verify(self, data):
        """
        decrypted data and verify tag
        """
        if (self.cipher == None):
            raise ValueError("init cipher before decrypte data")

        tag = data[-default_tag_ken:]
        return self.cipher.decrypt_and_verify(data[:-default_tag_ken], tag)

    def update(self, aad):
        """
        update cipher aad
        """
        if (self.cipher == None):
            raise ValueError("init cipher before update data")

        self.cipher.update(aad)

def decrypteKey(userKey, encryptedKey, iv):
    """
    Decrypt the encrypted key
    :param userKey: the key to be decrypted encryptedKey
    :param encryptedKey: crypted key to be decrypted
    :param iv: Initialization vector
    :return: decrypted result
    """
    encryptedKey = base64.b64decode(encryptedKey)

    Cipher = CipherLight(base64.b64decode(userKey), base64.b64decode(iv))
    Cipher.update(default_alg.encode())

    return Cipher.decrypte_and_verify(encryptedKey)

def encrypteKey(userKey, iv, key):
    """
    Encrypt key
    :param userKey: the key to encrypte key
    :param iv: Initialization vector
    :param key: the key to be encrypted
    :return: encrypted result
    """
    Cipher = CipherLight(base64.b64decode(userKey), base64.b64decode(iv))
    Cipher.update(default_alg.encode())

    res = Cipher.encrypte_and_verify(base64.b64decode(key))

    result = res[0] + res[1]

    return result

def get_random_key(len):
    """
    get random length byte data
    """
    return get_random_bytes(len)

def get_crypte_key():
    """
    generate crypte key, use default legth
    """
    return get_random_key(default_key_len)

def save_key(key, file_path):
    """
    :param key: the key to be saved
    :param file_path: save  path
    """
    key = base64.b64encode(key)
    with open(file_path, 'wb') as f:
        f.write(key)

def load_key(file_path):
    """
    load key from file
    :param file_path: key's path
    :return: key
    """
    with open(file_path, 'rb') as f:
        byte = f.read()

    return base64.b64decode(byte)

def parse_url(src):
    """
    Packaging data into URL format encoding
    """
    py_version = sys.version_info[0]

    if py_version == 2:
        return urllib.quote(src.encode("utf-8"), safe='+/')
    else:
        return urllib.parse.quote(src, safe='+/')

def decode_url(src):
    """
    decode URL format data
    """
    py_version = sys.version_info[0]

    if py_version == 2:
        return urllib.unquote(src.encode("utf-8"))
    else:
        return urllib.parse.unquote(src)


def get_meta_data(meta_data, key):
    if key not in meta_data:
        raise ValueError("key: " + key + " not in meta_data")

    return meta_data[key]

def adjust_chunk(default_chunk_size, data_len, tag_len):
    """
    The encrypted data is gradually parsed through chunk size,
    and we need to ensure that the last segment of data contains
    the verification data of the encrypted data, so we need to
    correct the chunk size
    """
    res = default_chunk_size

    if (data_len <= 16):
        return res

    while ((data_len % res) < tag_len):
        res += tag_len

    return res

def init_crypto_meta(file_path, encrypted_key, iv, args):
    """
    Assemble metadata data and save partial information of encrypted data
    """
    tag_len = default_tag_ken * 8

    file_init_len = os.path.getsize(file_path)
    file_encrypted_len = file_init_len + default_tag_ken

    crypto_meta = {
        "x-amz-cek-alg": str(default_alg),
        "x-amz-iv": parse_url(iv),
        "x-amz-key-v2": parse_url(encrypted_key),
        "x-amz-matdesc": "{}",
        "x-amz-tag-len": str(tag_len),
        "x-amz-wrap-alg": str(default_wrap_alg),
        "decoded-content-length": str(file_encrypted_len),
        "x-amz-unencrypted-content-length": str(file_init_len)
    }

    if "Metadata" in args:
        meta_data = args["Metadata"]
        meta_data.update(crypto_meta)
    else:
        args["Metadata"] = crypto_meta

def decode_meta_data(meta_data, user_key):
    """
    Analyze metadata data to decrypt data
    """
    wrap_alg = get_meta_data(meta_data, "x-amz-wrap-alg")
    if wrap_alg != default_wrap_alg:
        raise ValueError("not supported wrap alg: " + wrap_alg + " defaulting wrap alg: " + default_wrap_alg)

    alg = get_meta_data(meta_data, "x-amz-cek-alg")
    if alg != default_alg:
        raise ValueError("not supported algorithm: " + alg + " defaulting algorithm: " + default_alg)

    iv = decode_url(get_meta_data(meta_data, "x-amz-iv"))

    key_v2 = base64.b64decode(decode_url(get_meta_data(meta_data, "x-amz-key-v2")))
    tag_len = int(get_meta_data(meta_data, "x-amz-tag-len")) / 8

    iv_used_encrypted = key_v2[:default_iv_len]
    key_encrypted = key_v2[default_iv_len:]

    key_decrypt = decrypteKey(user_key, base64.b64encode(key_encrypted), base64.b64encode(iv_used_encrypted))

    return base64.b64decode(iv), key_decrypt, tag_len

def init_encrypt_body(file_path, cipher):
    """
    Wrap the data in ReadFileChunk format and encrypt it according to chunks when uploading
    """
    file_obj = open(file_path, 'rb')
    size = file_obj.tell() + os.path.getsize(file_path)

    if size == 0:
        data = cipher.encrypte_and_verify(b"")
        body = data[1]
    else:
        body = ReadFileChunk(file_obj, size, size, cipher=cipher)

    return body, file_obj, size



def get_object_decrypt(s3_client, user_key, file_path, bucket, key, **kwargs):
    """
    Get encrypted data interface. retrieve decrypted data from a remote location,
    and save the data in a specified file directory
    :param s3_client:  boto3 session client
    :param user_key: Encrypt data key
    :param file_path: used to save decrypted data
    :param bucket: Access bucket
    :param key: Access key
    :param kwargs:
    :return: get object response
    """

    # 1. get encrypted object into
    response = s3_client.get_object(Bucket=bucket, Key=key, **kwargs)

    # 2. decode encrypted info, include iv, key, object length ...
    crypted_length = int(response['ResponseMetadata']['HTTPHeaders']['content-length'])
    need_endecrypte = True

    iv, key, tag_len = decode_meta_data(response["Metadata"], user_key)

    # 3. init cipher to decrypt object
    chunk = default_chunk_size
    if need_endecrypte:
        cipher = CipherLight(key, iv)
        chunk = adjust_chunk(default_chunk_size, crypted_length, tag_len)

    stream = response['Body']

    # 4. decrtpy object, and write in file
    with open(file_path, 'wb') as file:
        i = 0

        if (crypted_length == default_tag_ken):
            return response

        while i < crypted_length:
            tmp_data = stream.read(chunk)

            if need_endecrypte:
                if (i + chunk) < crypted_length:
                    decrypted_data_chunk = cipher.decrypte(tmp_data)
                else:
                    decrypted_data_chunk = cipher.decrypte_and_verify(tmp_data)
            else:
                decrypted_data_chunk = tmp_data

            i += chunk

            file.write(decrypted_data_chunk)

    # 5. return response
    return response

def put_object_encrypt(s3_client, user_key, file_path, bucket,
                        key, **kwargs):
    """
    Put encrypted data interface
    :param s3_client:  boto3 session client
    :param user_key: Encrypt data key
    :param file_path: the file to be upload
    :param bucket: Access bucket
    :param key: Access key
    :param kwargs:
    :return: put object response
    """
    # 1. generate randowm key and iv，used to encrypted data
    random_key = get_random_key(default_key_len)
    random_iv = get_random_key(default_iv_len)

    # 2. init cipher
    cipher = CipherLight(random_key, random_iv)

    # 3. encrypt random key
    random_iv_for_key = get_random_key(default_iv_len)
    encrypted_key = base64.b64encode(random_iv_for_key + encrypteKey(user_key,
                                     base64.b64encode(random_iv_for_key),
                                     base64.b64encode(random_key)))

    # 4. init meta data
    init_crypto_meta(file_path, encrypted_key, base64.b64encode(random_iv), kwargs)

    # 5. init file obj
    file_obj, fp, size = init_encrypt_body(file_path, cipher)

    # 6. send put request
    if size != 0:
        with file_obj as body:
            respone = s3_client.put_object(Bucket=bucket, Key=key, Body=body, **kwargs)
    else:
        respone = s3_client.put_object(Bucket=bucket, Key=key, Body=file_obj, **kwargs)

    fp.close()

    return respone
